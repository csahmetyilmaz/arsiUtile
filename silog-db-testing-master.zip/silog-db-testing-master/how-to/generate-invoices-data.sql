-- Generate the ids that will be used in the following select queries (in (...))
select FAVE.NoFacture, -- Used to select from: FAVE, FAVC
  FAVE.CodeClient, -- Used to select from: CLI
  FAVC.CodeArticleprest, -- Used to select from: ARTICLE
  FAVC.NoAccuseRecepto, -- Used to select from: COMC
  (
    select ARTICLE.CodeFamille
    from ARTICLE
    where FAVC.CodeArticleprest = ARTICLE.CodeArticle
  ) as CodeFamille-- Used to select from: FAMRUB
from FAVE
  inner join CLI on FAVE.CodeClient = CLI.CodeClient
  inner join FAVC on FAVE.NoFacture = FAVC.NoFacture
where FAVE.NoFacture like 'AV21000%' -- Change this where clause to select other data
order by FAVE.NoFacture asc;

---------------- Replace the following 'in' clauses contents with the results of the previous query.
---- FAVE ----
SELECT * FROM FAVE WHERE NoFacture in
('AV2100001', 'AV2100002', 'AV2100003', 'AV2100004', 'AV2100005', 'AV2100006', 'AV2100007', 'AV2100008', 'AV2100011', 'AV2100012', 'AV2100013', 'AV2100014', 'AV2100015', 'AV2100016', 'AV2100017', 'AV2100018')

---- FAVC ----
SELECT * FROM FAVC WHERE NoFacture in
('AV2100001', 'AV2100002', 'AV2100003', 'AV2100004', 'AV2100005', 'AV2100006', 'AV2100007', 'AV2100008', 'AV2100011', 'AV2100012', 'AV2100013', 'AV2100014', 'AV2100015', 'AV2100016', 'AV2100017', 'AV2100018');

---- CLI -----
SELECT * FROM CLI WHERE CodeClient in
('NICOMATICINDIA', 'COMTRONIC', 'COMTRONIC', 'COMTRONIC', 'COMTRONIC', 'NICOMATIC USA', 'EXAGON', 'EXPLEOFRANCE', 'HEMERIA', 'HEMERIA', 'HEMERIA', 'NICOMATIC HONG-KONG', 'NICOMATICSINGA', 'NICOMATICSINGA', 'NICOMATICSINGA', 'EXPLEOFRANCE', 'EXPLEOFRANCE', 'ERTE', 'NICOMATIC CHINE', 'VIRAGE', 'DICOELECTRONIC', 'STENELECTRONIC');

-- ARTICLE ---
SELECT * FROM ARTICLE WHERE CodeArticle in
('C14764', '13507', '30-2300-CMM', '30-1300-CMM', '221E00F24-0002-3310', 'FGESTION', 'FGESTION', 'DIVERS', 'DIVERS', 'DIVERS', 'FGESTION', '222Y20M46H', '222Y20M46H', '221S20F60', 'CMM-C2-15', 'CMM-C2-11', '221D00F24-0004-130045', '14106-32', '11506-12', '1L-10-11M-16-1', '222S06M16-0002-4305', '222S10M16', '222S04M16');

---- COMC ----
SELECT * FROM COMC WHERE NoAccuseRecepto in
('AR2016855', 'AR2016855', 'AR2016855', 'AR2016855', 'AR2017734', 'AR2018253', 'AR2018253', 'AR2018253', 'AR2017237', 'AR2017237', 'AR2012562', 'AR2011880', 'AR2019548', 'AR2017597', 'AR2018463');

--- FAMRUB ---
SELECT * FROM FAMRUB WHERE CodeFamille in
('54', '47', '51', '01', '67');
