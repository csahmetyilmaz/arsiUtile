
## Database startup
1. Install Docker
2. Open a terminal from the `invoices-test` directory.
3. Execute: `docker-compose up`
4. Connect to the database with the credentials:
   ```
   Host:       localhost
   Database:   SILOG
   User:       sa
   Password:   S1L0G_2021
   ```

## SQL tables export
The [mssql-scripter](https://github.com/microsoft/mssql-scripter/blob/dev/doc/usage_guide.md) tool can be used when the database definition needs to be changed. Installation instructions are available [here](https://github.com/microsoft/mssql-scripter/blob/dev/doc/installation_guide.md).

```bash
mssql-scripter -S "172.16.1.171\SILOG" -U ws -d SILOG_PROD -P "<PASSWORD_HERE>" \
   --include-objects FAVE CLI FAVC ARTICLE FAMRUB COMC \
   --exclude-indexes --exclude-primary-keys --exclude-triggers --exclude-unique-keys \
   --display-progress \
   -f ./init.sql
```

Prepend the `init.sql` file with the following:

```sql
DROP DATABASE SILOG;
CREATE DATABASE SILOG;
GO

USE [SILOG]
GO
```

## SQL data export
In order to change the testing data, example SQL queries to export productions data samples can be found in the [how-to/generate-invoices-data.sql](how-to/generate-invoices-data.sql) file.

Use an SQL Client (for example: DBeaver) to export the results to sql files as insert statements, and move them to the 'data' folder.

Prepend the the exported sql files with the following:

```sql
USE [SILOG]
GO
```
