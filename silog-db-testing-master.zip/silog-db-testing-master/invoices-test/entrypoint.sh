#!/bin/bash
database=SILOG
wait_time=5s
password=S1L0G_2021

# Wait for SQL Server to come up
echo Waiting for SQL Server to be ready for $wait_time...
sleep $wait_time

# Create the DB and the tables
echo Creating the database
/opt/mssql-tools/bin/sqlcmd -S 0.0.0.0 -U sa -P $password -i ./init.sql

# Import the data
for f in ./data/*; do
  echo Importing $f
  /opt/mssql-tools/bin/sqlcmd -S 0.0.0.0 -U sa -P $password -i $f
done
